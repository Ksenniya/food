package org.food.order.pages.operator_new_products;


import org.openqa.selenium.support.FindBy;

import ru.yandex.qatools.htmlelements.annotations.Name;
import ru.yandex.qatools.htmlelements.element.HtmlElement;

@Name("AuthorizationBlock")
@FindBy(css = ".thumbnail.col-md-6.text-left.ng-binding.ng-scope")
public class Meal extends HtmlElement {


}
