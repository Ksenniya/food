package org.food.order.pages.operator_all;
import org.openqa.selenium.support.FindBy;
import ru.yandex.qatools.htmlelements.annotations.Name;
import ru.yandex.qatools.htmlelements.element.Button;
import ru.yandex.qatools.htmlelements.element.HtmlElement;
import ru.yandex.qatools.htmlelements.element.TextInput;

@Name("NewOrderButton")
@FindBy(css = ".navbar-brand.nav-button")	
public class NewOrderButton extends HtmlElement {

}
