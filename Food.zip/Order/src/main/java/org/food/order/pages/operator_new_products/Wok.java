package org.food.order.pages.operator_new_products;

import org.openqa.selenium.support.FindBy;

import ru.yandex.qatools.htmlelements.annotations.Name;
import ru.yandex.qatools.htmlelements.element.HtmlElement;

@Name("AuthorizationBlock")
@FindBy(linkText = "WOK")
public class Wok extends HtmlElement {


}
