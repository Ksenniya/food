package org.food.order.pages.authorization;
import org.openqa.selenium.support.FindBy;
import ru.yandex.qatools.htmlelements.annotations.Name;
import ru.yandex.qatools.htmlelements.element.Button;
import ru.yandex.qatools.htmlelements.element.HtmlElement;
import ru.yandex.qatools.htmlelements.element.TextInput;

	

	@Name("AuthorizationBlock")
	@FindBy(name = "login-form")
	public class AuthorizationBlock extends HtmlElement {

		@Name("loginField")
		@FindBy(id = "inputLogin")
		private TextInput loginField;

		@Name("passwordField")
		@FindBy(id = "inputPassword")
		private TextInput passwordField;

		@Name("Button")
		@FindBy(css = ".btn")
		private Button login_button;

		public void enter_login(String login) {
			// TODO Auto-generated method stub
			loginField.sendKeys(login);
		}

		public void enter_password(String password) {
			// TODO Auto-generated method stub
			passwordField.sendKeys(password);
		}

		public void click_button() {
			// TODO Auto-generated method stub
			login_button.click();
		}

	}