package org.food.order;

import org.food.order.pages.authorization.AuthorizationPage;
import org.food.order.pages.operator_all.OperatorAllPage;
import org.food.order.pages.operator_new_products.OperatorNewProductsPage;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
//import org.openqa.selenium.htmlunit.HtmlUnitDriver;
import static org.junit.Assert.*;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Stepdefs {

	WebDriver driver;
	AuthorizationPage authorizationPage;
	OperatorAllPage operatorAllPage;
	OperatorNewProductsPage operatorNewProductsPage;
	String a;

	@Given("^User authorizes with \"(.*)\" and \"(.*)\"$")
	public void authorization_page_is_opened(String login, String password) {
		System.setProperty("webdriver.chrome.driver", "chromedriver");
		driver = new ChromeDriver();
		// driver = new HtmlUnitDriver();
		driver.get("http://93.158.194.208:6005/");
		authorizationPage = new AuthorizationPage(driver);
		authorizationPage.login(login, password);
	}

	@When("^User makes new order$")
	public void user_makes_new_order() throws InterruptedException {

		driver.get("http://93.158.194.208:6005/operator/all");
		operatorAllPage = new OperatorAllPage(driver);
		operatorAllPage.makeNewOrder();

	}

	@Then("Current page equals expected \"(.*)\"$")

	public void current_page_equals_expected_name(String expectedUrl) {
		String currentUrl = driver.getCurrentUrl();
		assertEquals(currentUrl, expectedUrl);
		driver.close();
	}
}